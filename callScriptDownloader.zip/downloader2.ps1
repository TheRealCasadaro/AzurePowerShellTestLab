#sets vaiable for the location of what we want to download
$url = "https://raw.githubusercontent.com/TheRealCasadaro/AzureRM/master/active-directory-new-domain-with-data/CallingScript.ps1"

#sets variable for the download location, in this case the its the directy of whe we execute the script from
$output = "$PSScriptRoot\CallingScript.ps1"

#sets variable for the current time from our local machine
$start_time = Get-Date

#creates a webclient object then invokes the Downlide file method and feeds it the input and output we defined earlier
(New-Object System.Net.WebClient).DownloadFile($url, $output)

Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"