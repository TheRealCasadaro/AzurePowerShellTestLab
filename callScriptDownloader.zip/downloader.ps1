$url = "http://mirror.internode.on.net/pub/test/10meg.test"
$url = "https://raw.githubusercontent.com/TheRealCasadaro/AzureRM/master/active-directory-new-domain-with-data/CallingScript.ps1"
$output = "$PSScriptRoot\CallingScript.ps1"
$start_time = Get-Date

$wc = New-Object System.Net.WebClient
$wc.DownloadFile($url, $output)
#OR
# (New-Object System.Net.WebClient).DownloadFile($url, $output)

Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"